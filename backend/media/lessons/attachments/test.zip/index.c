#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#define RESET   "\033[0m"
#define GREEN   "\033[32m"
#define BLUE    "\033[34m"
#define RED     "\033[31m"
#define WHITE   "\033[37m"

void header(const char *title, int w) {
    printf("╔");
    for (int i = 0; i < w; i++) printf("═");
    printf("╗\n");

    printf("║");
    int len = strlen(title);
    int p = (w - len) / 2;
    for (int i = 0; i < p; i++) printf(" ");
    printf(GREEN "%s" RESET, title);
    for (int i = 0; i < w - p - len; i++) printf(" ");
    printf("║\n");

    printf("╠");
    for (int i = 0; i < w; i++) printf("═");
    printf("╣\n");
}

void footer(int w) {
    printf("╚");
    for (int i = 0; i < w; i++) printf("═");
    printf("╝\n");
}

void list_dir(const char *path) {
    system("clear");
    header("Directory Explorer", 50);

    printf("║ Path: %s", path);
    int pad = 43 - strlen(path);
    for (int i = 0; i < pad; i++) printf(" ");
    printf("║\n");

    printf("╠");
    for (int i = 0; i < 50; i++) printf("═");
    printf("╣\n");

    DIR *dir = opendir(path);
    if (!dir) {
        printf(RED "Dir-ийг нээж чадсангүй!\n" RESET);
        return;
    }

    struct dirent *e;
    int count = 0;

    while ((e = readdir(dir)) != NULL) {
        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0)
            continue;

        int isDir = (e->d_type == DT_DIR);

        printf("║ %s%s %s" RESET, 
            isDir ? BLUE : WHITE,
            isDir ? "📁" : "📄",
            e->d_name
        );

        int pad = 45 - strlen(e->d_name);
        for (int i = 0; i < pad; i++) printf(" ");
        printf(" ║\n");

        count++;
    }

    closedir(dir);

    footer(50);
    printf(GREEN "Total: %d items\n" RESET, count);
}

void create_file() {
    char name[256];
    printf(GREEN "FILE iin нэр: " RESET);
    scanf("%s", name);

    FILE *f = fopen(name, "w");
    if (!f) {
        printf(RED "FILE үүсээгүй!\n" RESET);
        return;
    }
    fclose(f);

    printf(GREEN "FILE үүслээ: %s\n" RESET, name);
}

void create_folder() {
    char name[256];
    printf(GREEN "FOLDER iin нэр: " RESET);
    scanf("%s", name);

    if (mkdir(name, 0777) == 0)
        printf(BLUE "FOLDER үүслээ: %s\n" RESET, name);
    else
        printf(RED "FOLDER үүсээгүй!\n" RESET);
}

void delete_item() {
    char name[256];
    printf(RED "Устгах FILE/FOLDER iin нэр: " RESET);
    scanf("%s", name);

    if (access(name, F_OK) != 0) {
        printf(RED "Ийм зүйл байхгүй.\n" RESET);
        return;
    }

    char cmd[300];
    sprintf(cmd, "rm -rf %s", name);  
    system(cmd);

    printf(RED "Устгалаа: %s\n" RESET, name);
}

void menu() {
    printf("\n");
    header("Main Menu", 50);

    printf("║                                                  ║\n");
    printf("║ 1. Folder т байгаа зүйлс                         ║\n");
    printf("║ 2. File үүсгэх                                   ║\n");
    printf("║ 3. Folder үүсгэх                                 ║\n");
    printf("║ 4. Delete                                        ║\n");
    printf("║ 5. Exit                                          ║\n");
    printf("║                                                  ║\n");

    footer(50);
}

int main() {
    char current_path[5] = ".";

    while (1) {
        menu();
        printf(GREEN "Сонголт: " RESET);

        int choice;
        scanf("%d", &choice);

        if (choice == 1) list_dir(current_path);
        else if (choice == 2) create_file();
        else if (choice == 3) create_folder();
        else if (choice == 4) delete_item();
        else if (choice == 5) {
            printf(GREEN "Bye!\n" RESET);
            break;
        } 
        else printf(RED "Буруу сонголт!\n" RESET);

        printf(WHITE "\nEnter дарж үргэлжлүүл…" RESET);
        getchar();
        getchar();
        system("clear");
    }

    return 0;
}
